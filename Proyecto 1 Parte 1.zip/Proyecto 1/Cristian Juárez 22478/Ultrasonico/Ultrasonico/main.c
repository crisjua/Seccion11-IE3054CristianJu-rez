/*
 * Ultrasonico.c
 *
 * Created: 5/8/2026 17:38:47
 * Author : crist
 */ 
#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <stdint.h>
#include "Ultrasonico/Ultrasonico.h"
#include "I2C/I2C.h"

#define IN1_DDR   DDRD
#define IN1_PORT  PORTD
#define IN1_PIN   PD2

#define IN2_DDR   DDRD
#define IN2_PORT  PORTD
#define IN2_PIN   PD3

#define LED_DDR   DDRC
#define LED_PORT  PORTC
#define LED_PIN   PC0

// Variables globales de I2C.c
extern volatile uint8_t I2C_SlaveData;

static inline void motor_init(void) {
	IN1_DDR |= (1 << IN1_PIN);
	IN2_DDR |= (1 << IN2_PIN);
}

static inline void motor_forward(void) {
	IN1_PORT |= (1 << IN1_PIN);
	IN2_PORT &= ~(1 << IN2_PIN);
}

static inline void motor_stop(void) {
	IN1_PORT &= ~(1 << IN1_PIN);
	IN2_PORT &= ~(1 << IN2_PIN);
}

static inline void led_init(void) { LED_DDR |= (1 << LED_PIN); }
static inline void led_on(void)   { LED_PORT |= (1 << LED_PIN); }
static inline void led_off(void)  { LED_PORT &= ~(1 << LED_PIN); }

int main(void) {
	motor_init();
	led_init();

	// Inicializa esclavo I2C en direcci�n 0x40
	I2C_Slave_Init(0x40);

	while (1) {
		cli();
		int16_t d = ultrasonic_read_cm_blocking();
		sei();

		if (d > 0 && d > 20) {
			motor_forward(); // sigue subiendo
			led_off();
			// No actualiza I2C_SlaveData, mantiene �ltimo valor
			} else if (d > 0 && d <= 20) {
			motor_stop();    // lleg� al piso
			led_on();
			// Solo aqu� actualiza el dato para el maestro
			if (d > 255) d = 255;       // limitar a 1 byte
			I2C_SlaveData = (uint8_t)d;
			} else {
			motor_stop();    // error de lectura ? seguridad
			led_off();
			I2C_SlaveData = 0; // error ? enviar 0
		}

		_delay_ms(100);
	}
}
