/*
 * Sensor de Peso.c
 *
 * Created: 6/8/2026 10:32:03
 * Author : crist
 */ 
#define F_CPU 16000000UL
#include <avr/io.h>
#include <avr/interrupt.h>   // necesario para sei() y cli()
#include <stdlib.h>
#include <util/delay.h>
#include "HX711/hx711.h"
#include "I2C/I2C_Esclavo.h" // librer�a de esclavo I2C

// Variable definida en I2C_Esclavo.c; se declara aqu� para poder
// actualizarla con la lectura del HX711 en cada ciclo del while(1)
extern volatile uint16_t tx_snap;

// ---------- UART ----------
void USART_Init(unsigned int ubrr) {
	UBRR0H = (unsigned char)(ubrr>>8);
	UBRR0L = (unsigned char)ubrr;
	UCSR0B = (1<<TXEN0);              // habilita transmisi�n
	UCSR0C = (1<<UCSZ01)|(1<<UCSZ00); // 8 bits de datos
}

void USART_Transmit(unsigned char data) {
	while (!(UCSR0A & (1<<UDRE0)));   // espera buffer libre
	UDR0 = data;
}

void USART_SendString(const char* str) {
	while (*str) {
		USART_Transmit(*str++);
	}
}

// ---------- MAIN ----------
int main(void) {
	HX711_init();
	USART_Init(103); // 9600 baudios con F_CPU=16MHz
	_delay_ms(800);
	
	// ---- activar esclavo I2C en direcci�n 0x08 ----
	I2C_Slave_Init(0x08);
	sei(); // habilitar interrupciones globales
	
	while (1) {
		// ---- proteger toda la lectura del HX711 ----
		cli();
		long raw = HX711_read_avg(4); // lee promedio de 4 lecturas
		sei();
		
		// ---- publicar la lectura para que el Maestro la lea por I2C ----
		if (raw < 0) raw = 0;
		if (raw > 65535) raw = 65535;
		tx_snap = (uint16_t)raw;
		
		// ---- debug por UART ----
		char buffer[20];
		ltoa(raw, buffer, 10);
		USART_SendString("Lectura HX711: ");
		USART_SendString(buffer);
		USART_SendString("\r\n");
		
		_delay_ms(200); // tiempo de refresco
	}
}
