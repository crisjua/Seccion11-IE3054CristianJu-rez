/*
 * I2C_Esclavo.c
 *
 * Created: 6/8/2026 12:21:56
 *  Author: crist
 */ 



#include "I2C_Esclavo.h"

// Variables globales
volatile uint16_t tx_snap = 0;
volatile uint8_t tx_idx = 0;

void I2C_Slave_Init(uint8_t addr) {
	TWSR = 0x00;               // prescaler = 1
	TWAR = (addr << 1);        // direcci�n 7-bit
	TWCR = (1 << TWEN) | (1 << TWEA) | (1 << TWIE); // TWI + ACK + IRQ
}

// ISR: env�a snapshot consistente (MSB, LSB)
ISR(TWI_vect) {
	uint8_t s = TWSR & 0xF8;

	switch (s) {
		// Receptor (SLA+W)
		case 0x60: case 0x68:
		case 0x80: case 0x90:
		case 0x88: case 0x98:
		case 0xA0:
		tx_idx = 0;
		TWCR = (1 << TWINT)|(1 << TWEN)|(1 << TWEA)|(1 << TWIE);
		break;

		// Transmisor (SLA+R)
		case 0xA8: // own SLA+R
		case 0xB0: // arb lost + SLA+R
		// Captura snapshot at�mico
		tx_idx = 0;
		// Enviar MSB
		TWDR = (uint8_t)((tx_snap >> 8) & 0xFF);
		tx_idx = 1;
		TWCR = (1 << TWINT)|(1 << TWEN)|(1 << TWEA)|(1 << TWIE);
		break;

		case 0xB8: // dato transmitido; ACK
		if (tx_idx == 1) {
			// Enviar LSB del mismo snapshot
			TWDR = (uint8_t)(tx_snap & 0xFF);
			tx_idx = 2;
			} else {
			// Si pide m�s, repite LSB
			TWDR = (uint8_t)(tx_snap & 0xFF);
		}
		TWCR = (1 << TWINT)|(1 << TWEN)|(1 << TWEA)|(1 << TWIE);
		break;

		case 0xC0: // dato transmitido; NACK (fin)
		case 0xC8: // �ltimo dato transmitido; ACK
		default:
		tx_idx = 0;
		TWCR = (1 << TWINT)|(1 << TWEN)|(1 << TWEA)|(1 << TWIE);
		break;
	}
}