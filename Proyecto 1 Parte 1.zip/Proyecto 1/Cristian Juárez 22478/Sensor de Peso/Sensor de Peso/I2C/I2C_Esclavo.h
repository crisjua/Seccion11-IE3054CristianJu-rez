/*
 * I2C_Esclavo.h
 *
 * Created: 6/8/2026 12:22:12
 *  Author: crist
 */ 


#ifndef I2C_SLAVE_H
#define I2C_SLAVE_H

#include <avr/io.h>
#include <avr/interrupt.h>

// Prototipos de funciones
void I2C_Slave_Init(uint8_t addr);

// Variables globales externas
extern volatile uint16_t tx_snap;
extern volatile uint8_t tx_idx;

#endif